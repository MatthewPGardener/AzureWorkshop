<#
 .SYNOPSIS
    Deploys a template to Azure

 .DESCRIPTION
    Deploys an Azure Resource Manager template

 .PARAMETER subscriptionId
    The subscription id where the template will be deployed.

 .PARAMETER resourceGroupName
    The resource group where the template will be deployed. Can be the name of an existing or a new resource group.

 .PARAMETER resourceGroupLocation
    Optional, a resource group location. If specified, will try to create a new resource group in this location. If not specified, assumes resource group is existing.

 .PARAMETER deploymentName
    The deployment name.

 .PARAMETER templateFilePath
    Optional, path to the template file. Defaults to template.json.

 .PARAMETER parametersFilePath
    Optional, path to the parameters file. Defaults to parameters.json. If file is not found, will prompt for parameter values based on template.
#>

param(
 [Parameter(Mandatory=$True)]
 [string]
 $deploymentName,

 [Parameter(Mandatory=$True)]
 [string]
 $subscriptionId,


 [string]
 $resourceGroupNameRGCorpCloud = 'RG-CorpCloud',

 [string]
 $resourceGroupLocationRGCorpCloud = 'uksouth',


 [string]
 $resourceGroupNameRGCorpOnPrem = 'RG-CorpOnPrem',

 [string]
 $resourceGroupLocationRGCorpOnPrem = 'uksouth',

 [string]
 $resourceGroupNameRGEuropePublic = 'RG-EuropePublic',

 [string]
 $resourceGroupLocationRGEuropePublic = 'northeurope',



 [string]
 $templateFilePath = "template.json",

 [string]
 $parametersFilePath = "parameters.json"
)

<#
.SYNOPSIS
    Registers RPs
#>
Function RegisterRP {
    Param(
        [string]$ResourceProviderNamespace
    )

    Write-Host "Registering resource provider '$ResourceProviderNamespace'";
    Register-AzResourceProvider -ProviderNamespace $ResourceProviderNamespace;
}

#******************************************************************************
# Script body
# Execution begins here
#******************************************************************************
$ErrorActionPreference = "Stop"

#sign in
#Write-Host "Logging in...";
#Login-AzAccount;

# select subscription
Write-Host "Selecting subscription '$subscriptionId'";
Select-AzSubscription -SubscriptionID $subscriptionId;

# Register RPs
$resourceProviders = @("microsoft.compute","microsoft.network","microsoft.storage");
if($resourceProviders.length) {
    Write-Host "Registering resource providers"
    foreach($resourceProvider in $resourceProviders) {
        RegisterRP($resourceProvider);
    }
}

#Create or check for existing resource group 1
$resourceGroupRGCorpCloud = Get-AzResourceGroup -Name $resourceGroupNameRGCorpCloud -ErrorAction SilentlyContinue
if(!$resourceGroupRGCorpCloud)
{
    Write-Host "Resource group '$resourceGroupNameRGCorpCloud' does not exist. To create a new resource group, please enter a location.";
    if(!$resourceGroupLocationRGCorpCloud) {
        $resourceGroupLocationRGCorpCloud = Read-Host "resource Group Location RGCorpCloud";
    }
    Write-Host "Creating resource group '$resourceGroupNameRGCorpCloud' in location '$resourceGroupLocationRGCorpCloud'";
    New-AzResourceGroup -Name $resourceGroupNameRGCorpCloud -Location $resourceGroupLocationRGCorpCloud
}
else{
    Write-Host "Using existing resource group '$resourceGroupNameRGCorpCloud'";
}

#Create or check for existing resource group 2
$resourceGroupRGCorpOnPrem = Get-AzResourceGroup -Name $resourceGroupNameRGCorpOnPrem -ErrorAction SilentlyContinue
if(!$resourceGroupRGCorpOnPrem)
{
    Write-Host "Resource group '$resourceGroupNameRGCorpOnPrem' does not exist. To create a new resource group, please enter a location.";
    if(!$resourceGroupLocationRGCorpOnPrem) {
        $resourceGroupLocationRGCorpOnPrem = Read-Host "resource Group Location RGCorpOnPrem";
    }
    Write-Host "Creating resource group '$resourceGroupNameRGCorpOnPrem' in location '$resourceGroupLocationRGCorpOnPrem'";
    New-AzResourceGroup -Name $resourceGroupNameRGCorpOnPrem -Location $resourceGroupLocationRGCorpOnPrem
}
else{
    Write-Host "Using existing resource group '$resourceGroupNameRGCorpOnPrem'";
}

#Create or check for existing resource group 3
$resourceGroupRGEuropePublic = Get-AzResourceGroup -Name $resourceGroupNameRGEuropePublic -ErrorAction SilentlyContinue
if(!$resourceGroupRGEuropePublic)
{
    Write-Host "Resource group '$resourceGroupNameRGEuropePublic' does not exist. To create a new resource group, please enter a location.";
    if(!$resourceGroupLocationRGEuropePublic) {
        $resourceGroupLocationRGEuropePublic = Read-Host "resource Group Location RGEuropePublic";
    }
    Write-Host "Creating resource group '$resourceGroupNameRGEuropePublic' in location '$resourceGroupLocationRGEuropePublic'";
    New-AzResourceGroup -Name $resourceGroupNameRGEuropePublic -Location $resourceGroupLocationRGEuropePublic
}
else{
    Write-Host "Using existing resource group '$resourceGroupNameRGEuropePublic'";
}

# Start the deployment
Write-Host "Starting deployment...";
if(Test-Path $parametersFilePath) {
    New-AzResourceGroupDeployment -ResourceGroupName $resourceGroupNameRGCorpCloud -TemplateFile $templateFilePath -TemplateParameterFile $parametersFilePath -verbose;
} else {
    New-AzResourceGroupDeployment -ResourceGroupName $resourceGroupNameRGCorpCloud -TemplateFile $templateFilePath -verbose;
}