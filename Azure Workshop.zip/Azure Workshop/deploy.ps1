<#
 .SYNOPSIS
    Deploys a template to Azure

 .DESCRIPTION
    Deploys an Azure Resource Manager template

 .PARAMETER subscriptionId
    The subscription id where the template will be deployed.

 .PARAMETER resourceGroupName
    The resource group where the template will be deployed. Can be the name of an existing or a new resource group.

 .PARAMETER resourceGroupLocation
    Optional, a resource group location. If specified, will try to create a new resource group in this location. If not specified, assumes resource group is existing.

 .PARAMETER deploymentName
    The deployment name.

 .PARAMETER templateFilePath
    Optional, path to the template file. Defaults to template.json.

 .PARAMETER parametersFilePath
    Optional, path to the parameters file. Defaults to parameters.json. If file is not found, will prompt for parameter values based on template.
#>

param(
 [Parameter(Mandatory=$True)]
 [string]
 $deploymentName,


 [string]
 $subscriptionId = '05082461-5092-4c47-b70c-b3c7750ce436',


 [string]
 $resourceGroupNameRGCorpCloud = 'RG-CorpCloud',

 [string]
 $resourceGroupLocationRGCorpCloud = 'UK South',


 [string]
 $resourceGroupNameRGCorpOnPrem = 'RG-CorpOnPrem',

 [string]
 $resourceGroupLocationRGCorpOnPrem = 'UK South',

 [string]
 $resourceGroupNameRGUKPublic = 'RG-EuropePublic',

 [string]
 $resourceGroupLocationRGUKPublic = 'UK South',



 [string]
 $templateFilePath = "template.json",

 [string]
 $parametersFilePath = "parameters.json"
)

<#
.SYNOPSIS
    Registers RPs
#>
Function RegisterRP {
    Param(
        [string]$ResourceProviderNamespace
    )

    Write-Host "Registering resource provider '$ResourceProviderNamespace'";
    Register-AzureRmResourceProvider -ProviderNamespace $ResourceProviderNamespace;
}

#******************************************************************************
# Script body
# Execution begins here
#******************************************************************************
$ErrorActionPreference = "Stop"

#sign in
#Write-Host "Logging in...";
#Login-AzureRmAccount;

# select subscription
Write-Host "Selecting subscription '$subscriptionId'";
Select-AzureRmSubscription -SubscriptionID $subscriptionId;

# Register RPs
$resourceProviders = @("microsoft.compute","microsoft.network","microsoft.storage");
if($resourceProviders.length) {
    Write-Host "Registering resource providers"
    foreach($resourceProvider in $resourceProviders) {
        RegisterRP($resourceProvider);
    }
}

#Create or check for existing resource group 1
$resourceGroupRGCorpCloud = Get-AzureRmResourceGroup -Name $resourceGroupNameRGCorpCloud -ErrorAction SilentlyContinue
if(!$resourceGroupRGCorpCloud)
{
    Write-Host "Resource group '$resourceGroupNameRGCorpCloud' does not exist. To create a new resource group, please enter a location.";
    if(!$resourceGroupLocationRGCorpCloud) {
        $resourceGroupLocationRGCorpCloud = Read-Host "resource Group Location RGCorpCloud";
    }
    Write-Host "Creating resource group '$resourceGroupNameRGCorpCloud' in location '$resourceGroupLocationRGCorpCloud'";
    New-AzureRmResourceGroup -Name $resourceGroupNameRGCorpCloud -Location $resourceGroupLocationRGCorpCloud
}
else{
    Write-Host "Using existing resource group '$resourceGroupNameRGCorpCloud'";
}

#Create or check for existing resource group 2
$resourceGroupRGCorpOnPrem = Get-AzureRmResourceGroup -Name $resourceGroupNameRGCorpOnPrem -ErrorAction SilentlyContinue
if(!$resourceGroupRGCorpOnPrem)
{
    Write-Host "Resource group '$resourceGroupNameRGCorpOnPrem' does not exist. To create a new resource group, please enter a location.";
    if(!$resourceGroupLocationRGCorpOnPrem) {
        $resourceGroupLocationRGCorpOnPrem = Read-Host "resource Group Location RGCorpOnPrem";
    }
    Write-Host "Creating resource group '$resourceGroupNameRGCorpOnPrem' in location '$resourceGroupLocationRGCorpOnPrem'";
    New-AzureRmResourceGroup -Name $resourceGroupNameRGCorpOnPrem -Location $resourceGroupLocationRGCorpOnPrem
}
else{
    Write-Host "Using existing resource group '$resourceGroupNameRGCorpOnPrem'";
}

#Create or check for existing resource group 3
$resourceGroupRGUKPublic = Get-AzureRmResourceGroup -Name $resourceGroupNameRGUKPublic -ErrorAction SilentlyContinue
if(!$resourceGroupRGUKPublic)
{
    Write-Host "Resource group '$resourceGroupNameRGUKPublic' does not exist. To create a new resource group, please enter a location.";
    if(!$resourceGroupLocationRGUKPublic) {
        $resourceGroupLocationRGUKPublic = Read-Host "resource Group Location RGUKPublic";
    }
    Write-Host "Creating resource group '$resourceGroupNameRGUKPublic' in location '$resourceGroupLocationRGUKPublic'";
    New-AzureRmResourceGroup -Name $resourceGroupNameRGUKPublic -Location $resourceGroupLocationRGUKPublic
}
else{
    Write-Host "Using existing resource group '$resourceGroupNameRGUKPublic'";
}

# Start the deployment
Write-Host "Starting deployment...";
if(Test-Path $parametersFilePath) {
    New-AzureRmResourceGroupDeployment -ResourceGroupName $resourceGroupNameRGCorpCloud -TemplateFile $templateFilePath -TemplateParameterFile $parametersFilePath -Verbose;
} else {
    New-AzureRmResourceGroupDeployment -ResourceGroupName $resourceGroupNameRGCorpCloud -TemplateFile $templateFilePath -Verbose;
}

# SIG # Begin signature block
# MIIFZAYJKoZIhvcNAQcCoIIFVTCCBVECAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUmKhE5p/BTrYxBafdr11jVdx3
# y0qgggMCMIIC/jCCAeagAwIBAgIQKAuTtucLlJ9Po58G94qu+TANBgkqhkiG9w0B
# AQsFADAXMRUwEwYDVQQDDAxDb2RlIFNpZ25pbmcwHhcNMTgwNzI0MTg0MzA2WhcN
# MTkwNzI0MTkwMzA2WjAXMRUwEwYDVQQDDAxDb2RlIFNpZ25pbmcwggEiMA0GCSqG
# SIb3DQEBAQUAA4IBDwAwggEKAoIBAQCgWfkovX/MrpJAHyjswSqAkRKdsG8YhFaI
# Sla71okkwAlEsYURuOOTVDcnCUA6ZuoCfRX+QuhyQszBedgAjPaOuvbLVhj1PsZP
# Tro+sWjP6Znu6Z58+nq0Y+MZE5nA+0a+lhOLmIJ7pDcnfyxCvjW4RqlNGXK4mRYo
# /LkJQGbEzcovWFuq2ckxG6TjJYh+r14bdcCfOLS1ooGUq/ei9F6R0bh+IWLU1YA9
# 5evPShXyx53f25FkBNTNuaY8RiiPwt8UGGUNdM8047YmKvVaq5FDxXnlu9GY+hfB
# V/qWlBHEfVrllVBqYuNrEoOkS7PZptAZNLDs/cvPGhtujGFIM0F1AgMBAAGjRjBE
# MA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAKBggrBgEFBQcDAzAdBgNVHQ4EFgQU
# jNxOvfol50teMPsTmAI/gQPUc0swDQYJKoZIhvcNAQELBQADggEBAGr4L2KNiSJv
# hpYq9wRXngeRFvMkFYdG5jav00NS7yli7k15rq5rmw7matRm2S3Ga8ExCRrHuMud
# LtLunOA6qwkdZz5jSHZsZgiMWsiw8W1xBMNBQHz5LKv+Hyf7Nn10M5D9kOWvtn5D
# JMslElwiZeDO1+dzbSQdMyAmvWUjCdKOriDcaQFZbENL137YtwT9oY5dC2mTwKEr
# mqDHt1ikmbTVbSHdccr7z1sYH/quBi7H0vNnDjuRL+VddFKVMLzr/mj1o2ljQRyk
# o7wausncVRjCwR5nL1z8lE1s45hx8PVcD+Fhu80SBhfyL5A1/1SZkwj1ESnWsk1B
# VvTJjErLwKMxggHMMIIByAIBATArMBcxFTATBgNVBAMMDENvZGUgU2lnbmluZwIQ
# KAuTtucLlJ9Po58G94qu+TAJBgUrDgMCGgUAoHgwGAYKKwYBBAGCNwIBDDEKMAig
# AoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgEL
# MQ4wDAYKKwYBBAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQUpB/bWbRKjRaqzWamDiu5
# e4Ls8icwDQYJKoZIhvcNAQEBBQAEggEAgy/xGU4vHJusUTTLTIJXcr1qKbWpgd6Z
# ylVzvHi2/RKXelsmG6s03Pi5bd+0xmxEVNzykf0vPFUK/J8d54HKhAVmqtimCodP
# PU+4N/B8/SL9PwH3uPe4rsQkpvYl0swZQlZUKghW8IyvDVAkTksB+kRyBKudfISu
# 5MlYQ+3Tp+eCZCzRW78vX1k0jnuECwA1FzpH6/4AeQFSBxNfjThl9X82alNgcCbm
# tvXhqnAtg+6xwZMv/AovlZCa54xR+9TQEdEnwnpBtBGQxlf0aHjl9B2InBTahCkD
# Z8DiG6Ag2StKEuh4HV6pu47QgzaiEd3MJautLqjaoK4zzG9mQwSiYA==
# SIG # End signature block
